
<?php
// Make connection with database
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'techsolve';

$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])) {
    //empty to store errors for form fields validatation
    $errors = [];

    $fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING);
    if (empty($fullname)) {
        $errors[] = "Full name is required";
    }

    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    if (empty($phone)) {
        $errors[] = "Phone number is required";
    }
    // else if ($phone != int()) {
    //     error[] = "Phone number must contain only valid integers.";
    // }

    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
    if (empty($email)) {
        $errors[] = "Email is required and should be valid";
    }

    $subject= filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
    if (empty($subject)) {
        $errors[] = "Subject is required";
    }

    $message= filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
    if (empty($message)) {
        $errors[] = "Message is required";
    }

    $sql_get_data = "SELECT email, phone FROM contact_form";
    $result_data = mysqli_query($conn, $sql_get_data);

    if (mysqli_num_rows($result_data) > 0) {
        while ($row = mysqli_fetch_assoc($result_data)) {
            $get_email = $row['email'];
            // $get_phone = $row['phone'];

            if($get_email == $email) {
                $errors[] = "You have already filled this form, Thankyou.";
            }
            // if($get_phone == $phone) {
            //     $errors[] = "You have already filled this form, Thankyou.";
            // }
        }
    }

    //If any error in form field, display the error and keeping the filled inputs logic
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p>".$error."</p>";
        }
    }
    else {
        //Proceed with database
        // $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

        if (!$conn) {
            die("Connection failed: ".mysqli_connect_error());
        }

        //Insert data-form-field to database's table "contact_form" 
        $ip_address = $_SERVER['REMOTE_ADDR'];
        $date_str = date("d-m-Y H:i:s");
        $timestamp = strtotime($date_str);

        $sql = "INSERT INTO contact_form (fullname, phone, email, subject, message, ip_address, `timestamp`) VALUES ('$fullname', '$phone', '$email', '$subject', '$message', '$ip_address', $timestamp)";

        if (mysqli_query($conn, $sql)) {
            echo "<p>Form submitted successfully</p>";
            $fullname = '';
            $phone = '';
            $email = '';
            $subject = '';
            $message = '';

            //Send email to owner/as per credentials
            $to = "showroomowner@gmail.com";
            $subject = "New Form Submission";
            $body = "Full Name: $fullname\n";
            $body .= "Phone Number: $phone\n";
            $body .= "Email: $email\n";
            $body .= "Subject: $subject\n";
            $body .= "Message: $message\n";
            $headers = "Form: sender@mailprop@gmail.com";

            // mail($to, $subject, $body, $headers);
        }
        else {
            echo "Error: ".$sql."<br>".mysqli_error($conn);
        }
        mysqli_close($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" action="">
        <label for="fullname">Full Name:</label>
        <input type="text" name="fullname" id="fullname"  value="<?php echo isset($fullname) ? htmlspecialchars($fullname) : ''; ?>"><br><br>

        <label for="phone">Phone Number:</label>
        <input type="tel" name="phone" id="phone" value="<?php echo isset($phone) ? htmlspecialchars($phone) : ''; ?>"><br><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>"><br><br>

        <label for="subject">Subject:</label>
        <input type="text" name="subject" id="subject" value="<?php echo isset($subject) ? htmlspecialchars($subject) : ''; ?>"><br><br>

        <label for="message">Message:</label>
        <textarea type="text" name="message" id="message"><?php echo isset($message) ? htmlspecialchars($message) : ''; ?></textarea><br><br>

        <input type="submit" value="Submit" name="submit"><br>
    <form>
</body>
</html>