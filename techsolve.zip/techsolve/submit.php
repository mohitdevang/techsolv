
<?php
//empty to store errors for form fields validatation
$errors = [];

$fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING);
if (empty($fullname)) {
    $errors[] = "Full name is required";
}

$phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
if (empty($phone)) {
    $errors[] = "Phone number is required";
}

$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_STRING);
if (empty($email)) {
    $errors[] = "Email is required and should be valid";
}

$subject= filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
if (empty($subject)) {
    $errors[] = "Subject is required";
}

$message= filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
if (empty($message)) {
    $errors[] = "Message is required";
}

//If any error in form field, display the error and keeping the filled inputs logic
if (!empty($errors)) {
    foreach ($errors as $error) {
        echo "<p>".$error."</p>";
    }
    echo "
        <script>
        document.getElementById('fullname').value = '$fullname';
        document.getElementById('phone').value = '$phone';
        document.getElementById('email').value = '$email';
        document.getElementById('subject').value = '$subject';
        document.getElementById('message').value = '$message';
        </script>    
    ";
}
else {
    // Make connection with database
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'techsolve';

    $conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

    if (!$conn) {
        die("Connection failed: ".mysqli_connect_error());
    }

    //Insert data-form-field to database's table "contact_form" 
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $timestamp = date('d-m-Y H:i:s');

    $sql = "INSERT INTO contact_form (fullname, phone, email, subject, message, ip_address, `timestamp`) VALUES ('$fullname', '$phone', '$email', '$subject', '$message', '$ip_address', '$timestamp')";

    if (mysqli_query($conn, $sql)) {
        echo "<p>Form submitted successfully</p>";

        //Send email to owner/as per credentials
        $to = "showroomowner@gmail.com";
        $subject = "New Form Submission";
        $body = "Full Name: $fullname\n";
        $body .= "Phone Number: $phone\n";
        $body .= "Email: $email\n";
        $body .= "Subject: $subject\n";
        $body .= "Message: $message\n";
        $headers = "Form: sender@mailprop@gmail.com";

        mail($to, $subject, $body, $headers);
    }
    else {
        echo "Error: ".$sql."<br>".mysqli_error($conn);
    }
    mysqli_close($conn);
}

?>